# NurseNext browser MVP

Open `index.html` in a browser to test. Includes career assessment, ranked career exploration, factual resume summary template, local application tracker, and rule-based interview feedback.

## Deploy static preview
Upload `index.html` to a static host (e.g. Netlify Drop or GitHub Pages). This is a demo, not a production-ready paid app.

## Production gaps
- Supabase Auth, PostgreSQL and row-level security
- Server-side verified role requirements and job data
- OpenAI API integration with factual safeguards
- Stripe Checkout and verified webhook access control
- Privacy policy, terms, deletion workflows, consent, logging, rate limiting, accessibility/security testing
- Domain, analytics, transactional email, backups, monitoring

No secrets should be embedded in client HTML. This demo uses browser localStorage for application tracking.
